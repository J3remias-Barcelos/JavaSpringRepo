package simpress.com.br.APIZendesk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiZendeskApplicationTests {

	@Test
	void contextLoads() {
	}

}
